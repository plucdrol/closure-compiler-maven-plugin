'use strict';console.log("Logging 1 (one)");console.log("Logging 1 (one)");console.log("Logging 1 (one)");console.log("Logging 2 (two)");console.log("Logging 2 (two)");console.log("Logging 2 (two)");
