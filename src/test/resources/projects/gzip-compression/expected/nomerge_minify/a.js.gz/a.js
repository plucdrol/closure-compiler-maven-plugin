'use strict';console.log("Logging 1 (one)");console.log("Logging 1 (one)");console.log("Logging 1 (one)");
